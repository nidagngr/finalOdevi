using System;
using System.Collections.Generic;
using System.Linq;

public class GrafAlgoritmaları
{
    public static void Main(string[] args)
    {
        // Grafı oluştur
        var graph = new Graph();
        graph.AddNode(1);
        graph.AddNode(2);
        graph.AddNode(3);
        graph.AddNode(4);
        graph.AddNode(5);
        graph.AddEdge(1, 2, 10);
        graph.AddEdge(1, 3, 5);
        graph.AddEdge(2, 3, 2);
        graph.AddEdge(2, 4, 6);
        graph.AddEdge(3, 4, 3);
        graph.AddEdge(3, 5, 9);
        graph.AddEdge(4, 5, 4);

        // Kullanıcıdan algoritma seçimini al
        Console.WriteLine("Lütfen bir algoritma seçin:");
        Console.WriteLine("1. Dijkstra");
        Console.WriteLine("2. Kruskal");
        Console.WriteLine("3. Prim");
        Console.Write("Seçiminizi girin: ");
        int secim = int.Parse(Console.ReadLine());

        // Seçilen algoritmaya göre işlemi gerçekleştir
        switch (secim)
        {
            case 1:
                // Dijkstra
                Console.WriteLine("Kaynak düğümü girin:");
                int kaynakDüğüm = int.Parse(Console.ReadLine());
                var enKisaYollar = Dijkstra.FindShortestPaths(kaynakDüğüm, graph);
                Console.WriteLine("En kısa yollar:");
                foreach (var yol in enKisaYollar)
                {
                    Console.WriteLine($"Düğüm {yol.Key} için mesafe: {yol.Value}");
                }
                break;

            case 2:
                // Kruskal
                var minimumYayılımAgaci = Kruskal.FindMinimumSpanningTree(graph);
                Console.WriteLine("Minimum yayılım ağacı:");
                foreach (var kenar in minimumYayılımAgaci)
                {
                    Console.WriteLine($"Düğüm {kenar.Item1} - Düğüm {kenar.Item2}, Ağırlık: {kenar.Item3}");
                }
                break;

            case 3:
                // Prim
                var primMinimumYayılımAgaci = Prim.FindMinimumSpanningTree(graph);
                Console.WriteLine("Prim algoritması ile bulunan minimum yayılım ağacı:");
                foreach (var kenar in primMinimumYayılımAgaci)
                {
                    Console.WriteLine($"Düğüm {kenar.Item1} - Düğüm {kenar.Item2}, Ağırlık: {kenar.Item3}");
                }
                break;

            default:
                Console.WriteLine("Geçersiz seçim.");
                break;
        }

        Console.ReadKey();
    }
}

// Graf sınıfı
public class Graph
{
    private Dictionary<int, List<int>> _nodes;
    private Dictionary<(int, int), int> _edgeWeights;

    public Graph()
    {
        _nodes = new Dictionary<int, List<int>>();
        _edgeWeights = new Dictionary<(int, int), int>();
    }

    public void AddNode(int node)
    {
        if (!_nodes.ContainsKey(node))
        {
            _nodes[node] = new List<int>();
        }
    }

    public void AddEdge(int source, int target, int weight)
    {
        _nodes[source].Add(target);
        _nodes[target].Add(source); // Yönlendirilmemiş bir graf için
        _edgeWeights[(source, target)] = weight;
    }

    public List<int> Neighbors(int node)
    {
        return _nodes[node];
    }

    public int EdgeWeight(int source, int target)
    {
        return _edgeWeights[(source, target)];
    }

    public IEnumerable<int> Nodes
    {
        get { return _nodes.Keys; }
    }

    public List<(int, int, int)> Edges
    {
        get
        {
            return _edgeWeights.Select(e => (e.Key.Item1, e.Key.Item2, e.Value)).ToList();
        }
    }
}

// Dijkstra algoritması
public class Dijkstra
{
    public static Dictionary<int, int> FindShortestPaths(int source, Graph graph)
    {
        // Tüm düğümlerin mesafelerini sonsuz olarak başlat
        var distances = new Dictionary<int, int>();
        foreach (var node in graph.Nodes)
        {
            distances[node] = int.MaxValue;
        }
        distances[source] = 0;

        // Ziyaret edilmemiş düğümleri izlemek için bir kuyruk kullan
        var queue = new Queue<int>();
        queue.Enqueue(source);

        // Tüm düğümler ziyaret edilene kadar döngüye gir
        while (queue.Count > 0)
        {
            // Kuyruktan bir düğüm çıkar
            var current = queue.Dequeue();

            // Düğümün komşularını yinele
            foreach (var neighbor in graph.Neighbors(current))
            {
                // Komşunun mesafesini güncelle
                var distance = distances[current] + graph.EdgeWeight(current, neighbor);
                if (distance < distances[neighbor])
                {
                    distances[neighbor] = distance;
                    queue.Enqueue(neighbor);
                }
            }
        }

        return distances;
    }
}

// Kruskal algoritması
public class Kruskal
{
    public static List<(int, int, int)> FindMinimumSpanningTree(Graph graph)
    {
        // Tüm kenarları ağırlıklarına göre sıralayın
        var edges = graph.Edges.OrderBy(e => e.Item3).ToList();

        // Boş bir ağacı başlat
        var mst = new List<(int, int, int)>();

        // Her bir kenarı yinele
        foreach (var (source, target, weight) in edges)
        {
            // Eğer kenar ağaca bir döngü eklemezse:
            if (!HasCycle(source, target, mst))
            {
                // Kenarı ağaca ekleyin
                mst.Add((source, target, weight));
            }
        }

        return mst;
    }

    // Ağaçta bir döngü olup olmadığını kontrol eder
    private static bool HasCycle(int source, int target, List<(int, int, int)> mst)
    {
        // İki düğüm aynı bileşendeyse döngü vardır
        return FindParent(source, mst) == FindParent(target, mst);
    }

    // Bir düğümün atasını bulur
    private static int FindParent(int node, List<(int, int, int)> mst)
    {
        // Ağaçta düğüm yoksa, kendisi kendi atasıdır
        if (!mst.Any(e => e.Item1 == node || e.Item2 == node))
        {
            return node;
        }

        // Atasını bulmak için ağacı yukarı doğru tırman
        var parent = mst.First(e => e.Item1 == node || e.Item2 == node).Item1 == node ? mst.First(e => e.Item1 == node || e.Item2 == node).Item2 : mst.First(e => e.Item1 == node || e.Item2 == node).Item1;
        return FindParent(parent, mst);
    }
}

// Prim algoritması
public class Prim
{
    public static List<(int, int, int)> FindMinimumSpanningTree(Graph graph)
    {
        // Başlangıç düğümünü seçin
        var startNode = graph.Nodes.First();

        // Boş bir ağacı başlat
        var mst = new List<(int, int, int)>();

        // Tüm düğümlerin mesafelerini sonsuz olarak başlat
        var distances = new Dictionary<int, int>();
        foreach (var node in graph.Nodes)
        {
            distances[node] = int.MaxValue;
        }
        distances[startNode] = 0;

        // Ziyaret edilmemiş düğümleri izlemek için bir kuyruk kullan
        var queue = new Queue<int>();
        queue.Enqueue(startNode);

        // Tüm düğümler ziyaret edilene kadar döngüye gir
        while (queue.Count > 0)
        {
            // Kuyruktan bir düğüm çıkar
            var current = queue.Dequeue();

            // Düğümün komşularını yinele
            foreach (var neighbor in graph.Neighbors(current))
            {
                // Komşunun mesafesini güncelle
                var distance = graph.EdgeWeight(current, neighbor);
                if (distance < distances[neighbor])
                {
                    distances[neighbor] = distance;
                    queue.Enqueue(neighbor);
                }
            }

            // Ağaca en düşük ağırlıklı kenarın bulunduğu düğümü ekleyin
            var minDistance = distances.Where(d => !mst.Any(e => e.Item1 == d.Key || e.Item2 == d.Key)).Min(d => d.Value);
            var newNode = distances.Where(d => !mst.Any(e => e.Item1 == d.Key || e.Item2 == d.Key)).First(d => d.Value == minDistance).Key;
            var edge = graph.Edges.First(e => (e.Item1 == current && e.Item2 == newNode) || (e.Item1 == newNode && e.Item2 == current));
            mst.Add(edge);
        }

        return mst;
    }
}