﻿using System;
using System.Collections.Generic;
using System.Linq;

public class GrafAlgoritmaları
{
    public static void Main(string[] args)
    {
        // Grafı oluştur
        var graph = new Graph();
        graph.AddNode(1);
        graph.AddNode(2);
        graph.AddNode(3);
        graph.AddNode(4);
        graph.AddNode(5);
        graph.AddEdge(1, 2, 10);
        graph.AddEdge(1, 3, 5);
        graph.AddEdge(2, 3, 2);
        graph.AddEdge(2, 4, 6);
        graph.AddEdge(3, 4, 3);
        graph.AddEdge(3, 5, 9);
        graph.AddEdge(4, 5, 4);

        // Kullanıcıdan algoritma seçimini al
        Console.WriteLine("Lütfen bir algoritma seçin:");
        Console.WriteLine("1. Dijkstra");
        Console.WriteLine("2. Kruskal");
        Console.WriteLine("3. Prim");
        Console.Write("Seçiminizi girin: ");
        int secim = int.Parse(Console.ReadLine());

        // Seçilen algoritmaya göre işlemi gerçekleştir
        switch (secim)
        {
            case 1:
                // Dijkstra
                Console.WriteLine("Kaynak düğümü girin:");
                int kaynakDüğüm = int.Parse(Console.ReadLine());
                var enKisaYollar = Dijkstra.FindShortestPaths(kaynakDüğüm, graph);
                Console.WriteLine("En kısa yollar:");
                foreach (var yol in enKisaYollar)
                {
                    Console.WriteLine($"Düğüm {yol.Key} için mesafe: {yol.Value}");
                }
                break;

            case 2:
                // Kruskal
                var minimumYayılımAgaci = Kruskal.FindMinimumSpanningTree(graph);
                Console.WriteLine("Minimum yayılım ağacı:");
                foreach (var kenar in minimumYayılımAgaci)
                {
                    Console.WriteLine($"Düğüm {kenar.Item1} - Düğüm {kenar.Item2}, Ağırlık: {kenar.Item3}");
                }
                break;

            case 3:
                // Prim
                var primMinimumYayılımAgaci = Prim.FindMinimumSpanningTree(graph);
                Console.WriteLine("Prim algoritması ile bulunan minimum yayılım ağacı:");
                foreach (var kenar in primMinimumYayılımAgaci)
                {
                    Console.WriteLine($"Düğüm {kenar.Item1} - Düğüm {kenar.Item2}, Ağırlık: {kenar.Item3}");
                }
                break;

            default:
                Console.WriteLine("Geçersiz seçim.");
                break;
        }

        Console.ReadKey();
    }
}

// Graf sınıfı
public class Graph
{
    private Dictionary<int, List<int>> _nodes;
    private Dictionary<(int, int), int> _edgeWeights;

    public Graph()
    {
        _nodes = new Dictionary<int, List<int>>();
        _edgeWeights = new Dictionary<(int, int), int>();
    }

    public void AddNode(int node)
    {
        if (!_nodes.ContainsKey(node))
        {
            _nodes[node] = new List<int>();
        }
    }

    public void AddEdge(int source, int target, int weight)
    {
        if (!_nodes.ContainsKey(source) || !_nodes.ContainsKey(target))
            throw new ArgumentException("Source or target node does not exist.");

        _nodes[source].Add(target);
        _nodes[target].Add(source); // Yönlendirilmemiş bir graf için
        _edgeWeights[(source, target)] = weight;
        _edgeWeights[(target, source)] = weight; // Yönlendirilmemiş bir graf için
    }

    public List<int> Neighbors(int node)
    {
        return _nodes[node];
    }

    public int EdgeWeight(int source, int target)
    {
        return _edgeWeights[(source, target)];
    }

    public IEnumerable<int> Nodes
    {
        get { return _nodes.Keys; }
    }

    public List<(int, int, int)> Edges
    {
        get
        {
            return _edgeWeights.Select(e => (e.Key.Item1, e.Key.Item2, e.Value)).Distinct().ToList();
        }
    }
}

// Dijkstra algoritması
public class Dijkstra
{
    public static Dictionary<int, int> FindShortestPaths(int source, Graph graph)
    {
        var distances = new Dictionary<int, int>();
        foreach (var node in graph.Nodes)
        {
            distances[node] = int.MaxValue;
        }
        distances[source] = 0;

        var queue = new Queue<int>();
        queue.Enqueue(source);

        while (queue.Count > 0)
        {
            var current = queue.Dequeue();

            foreach (var neighbor in graph.Neighbors(current))
            {
                var distance = distances[current] + graph.EdgeWeight(current, neighbor);
                if (distance < distances[neighbor])
                {
                    distances[neighbor] = distance;
                    queue.Enqueue(neighbor);
                }
            }
        }

        return distances;
    }
}

// Kruskal algoritması
public class Kruskal
{
    public static List<(int, int, int)> FindMinimumSpanningTree(Graph graph)
    {
        var edges = graph.Edges.OrderBy(e => e.Item3).ToList();
        var parent = new Dictionary<int, int>();
        var rank = new Dictionary<int, int>();

        foreach (var node in graph.Nodes)
        {
            parent[node] = node;
            rank[node] = 0;
        }

        var mst = new List<(int, int, int)>();

        foreach (var (source, target, weight) in edges)
        {
            if (Find(source, parent) != Find(target, parent))
            {
                mst.Add((source, target, weight));
                Union(source, target, parent, rank);
            }
        }

        return mst;
    }

    private static int Find(int node, Dictionary<int, int> parent)
    {
        if (parent[node] != node)
        {
            parent[node] = Find(parent[node], parent);
        }
        return parent[node];
    }

    private static void Union(int u, int v, Dictionary<int, int> parent, Dictionary<int, int> rank)
    {
        int rootU = Find(u, parent);
        int rootV = Find(v, parent);

        if (rootU != rootV)
        {
            if (rank[rootU] > rank[rootV])
            {
                parent[rootV] = rootU;
            }
            else if (rank[rootU] < rank[rootV])
            {
                parent[rootU] = rootV;
            }
            else
            {
                parent[rootV] = rootU;
                rank[rootU]++;
            }
        }
    }
}

// Prim algoritması
public class Prim
{
    public static List<(int, int, int)> FindMinimumSpanningTree(Graph graph)
    {
        var startNode = graph.Nodes.First();
        var mst = new List<(int, int, int)>();
        var visited = new HashSet<int> { startNode };
        var edges = new PriorityQueue<(int, int, int), int>();

        foreach (var neighbor in graph.Neighbors(startNode))
        {
            edges.Enqueue((startNode, neighbor, graph.EdgeWeight(startNode, neighbor)), graph.EdgeWeight(startNode, neighbor));
        }

        while (edges.Count > 0)
        {
            var (source, target, weight) = edges.Dequeue();
            if (visited.Contains(target))
            {
                continue;
            }

            visited.Add(target);
            mst.Add((source, target, weight));

            foreach (var neighbor in graph.Neighbors(target))
            {
                if (!visited.Contains(neighbor))
                {
                    edges.Enqueue((target, neighbor, graph.EdgeWeight(target, neighbor)), graph.EdgeWeight(target, neighbor));
                }
            }
        }

        return mst;
    }
}
